import React from 'react'

const Text = () => {
  return (
    <div>
      
    </div>
  )
}

export default Text
