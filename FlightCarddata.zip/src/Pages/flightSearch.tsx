import React, { useState, useEffect, useRef } from "react";
import Drawer from "../Component/Drawer/Drawer";
import Loader from "../Component/Loader/Loader";
import "../App.css";
import { flightSearchRequest, ApiResponse } from "../apis/flightSearchApi";
import { FlightDetails } from "../Component/Types/Types";
import FlightCard from "./flightCard";
import Button from "../Component/Button/Button";
import networkPayLoad from "../apis/tempNetworkPayload";

const Flightsearch: React.FC = () => {
  const [loader, setLoader] = useState<boolean>(false);
  const [data, setData] = useState<FlightDetails[]>([]);
  const [openCards, setOpenCards] = useState<{ [key: number]: boolean }>({});
  const [pollingActive, setPollingActive] = useState<boolean>(false);
  const [timeElapsed, setTimeElapsed] = useState<number>(0);
  const [newData, setNewData] = useState();

  const flightCardRef = useRef<HTMLDivElement>(null);

  const POLLING_INTERVAL = 3000; // 3 seconds
  const MAX_POLLING_DURATION = 30000; // 30 seconds

  const toggleDrawer = (id: number) => {
    setOpenCards((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  useEffect(() => {
    const startPolling = async (elapsedTime: number) => {
      if (elapsedTime >= MAX_POLLING_DURATION) {
        setPollingActive(false); // Stop polling after max duration
        return;
      }

      try {
        console.log("Fetching data...");
        const response: ApiResponse = await flightSearchRequest(networkPayLoad);
        const flightsData: FlightDetails[] = response.data.flights;
        console.log("Fetched flight data:", flightsData); // This should now show the actual flight data

        if (flightsData && flightsData.length > 0) {
          setData(flightsData); // Set the flight data correctly in your state
        }

        if (response.poll) {
          setTimeout(() => {
            startPolling(elapsedTime + POLLING_INTERVAL);
          }, POLLING_INTERVAL);
        } else {
          setPollingActive(false);
        }
      } catch (error) {
        console.log("Error fetching data:", error);

        // Retry after delay if error occurs
        setTimeout(() => {
          startPolling(elapsedTime + POLLING_INTERVAL);
        }, POLLING_INTERVAL);
      }
    };

    if (pollingActive) {
      startPolling(0); // Start polling with an elapsed time of 0
    }

    return () => {
      setPollingActive(false); // Clean up on unmount or when polling stops
    };
  }, [pollingActive]);

  const startPollingonClick = () => {
    console.log("Starting polling...");
    setPollingActive(true);
  };


  useEffect(() => {
    let data:any = [];
    data.map((item:any) => {
      const segment = item.legs[0].segments[0];

      const flightObject = {
        provider: item.provider,
        airlineName: segment.operating_airline.name,
        airlineCode: segment.operating_airline.code,
        origin: segment.origin.iata_code,
        destination: segment.destination.iata_code,
        departureTime: segment.departure_datetime,
        arrivalTime: segment.arrival_datetime,
        has_meal: segment.has_meal,
      };

      console.log("flightObject", flightObject);
      data.push(flightObject);
    });

    setData(data);

  }, [data]);




  return (
    <>
      {loader && (
        <div className="spinner">
          <Loader />
        </div>
      )}
      <div className="Container">
        <div className="airblue_data">
          {data && data.length > 0 ? (
            data.map((flightdetails, index) => {

              // / Extract data from the leg and airline
              // console.log("Checking item" , item);

              console.log("Complete flight details for index:", index, flightdetails);

              const flightLeg = flightdetails.legs?.[0];  // Get the first leg if available
              const flightSegment = flightdetails.segments?.[0]; // Get the first segment if available
              const operatingAirline = flightSegment?.operating_airline;  // Get the airline details from the leg


              // Extract flight number from the segment
              const flightNumber = flightSegment?.flight_number?.[0] || ""; // Ensure it's a string

              // Extract other data from the leg and airline

              const provider = flightdetails.provider;
              const airlineName = operatingAirline?.airlineName || "";
              const airlineCode = operatingAirline?.airlineCode || "";
              const origin = flightLeg?.origin || "";  
              const destination = flightLeg?.destination || "";
              const departureTime = flightLeg?.departure_datetime || "";
              const arrivalTime = flightLeg?.arrival_datetime || "";
              const has_meal = flightdetails.has_meal || false;

              console.log({
                index,
                provider,
                flightLeg,
                flightSegment,
                airlineName: flightSegment?.operating_airline?.airlineName,
                flightNumber: flightSegment?.flight_number?.[0],
                origin: flightSegment?.origin?.iata_code,
                destination: flightSegment?.destination?.iata_code,
                // departureTime: flightSegment?.departure_datetime,
                // arrivalTime: flightSegment?.arrival_datetime,
              });

              return (
                <div key={index} ref={flightCardRef}>
                  {/* <FlightCard
                    id={index}
                    toggleDrawer={toggleDrawer}
                    isDrawerOpen={!!openCards[index]}
                    flightdetails={[flightdetails]}
                    provider={provider}
                    airlineName={airlineName}
                    airlineCode={airlineCode}
                    flightNumber={flightNumber}
                    origin={origin}
                    destination={destination}
                    departureTime={departureTime}
                    arrivalTime={arrivalTime}
                    has_meal={has_meal}
                  /> */}

                  {openCards[index] && (
                    <Drawer
                      isOpen={openCards[index]}
                      onClose={() => toggleDrawer(index)}
                      cardRef={flightCardRef}
                      flightdetails={[flightdetails]}>
                      <div className="container">
                        <table className="table_data">
                          <thead className="flight_options">
                            <tr>
                              <th>Fare Options</th>
                              <th>Check-in Baggage</th>
                              <th>Cancellation</th>
                              <th>Modification</th>
                              <th>Seat</th>
                              <th>Meal</th>
                              <th></th>
                            </tr>
                          </thead>
                          {/* <tbody>
                          <tr key={index}>
                            <td>{flightdetails.airlineName}</td>

                            <td>{baggage_info?.pieces || 0} x {baggage_info?.weight} {baggage_info?.unit}</td>
                            <td>{is_refundable ? "Yes" : "No"}</td>
                            <td>{should_auto_ticket ? "Yes" : "No"}</td>
                            <td>{flightSegment?.rbd || "N/A"}</td>
                            <td>{has_meal ? "Yes" : "No"}</td>
                            <td>
                              <Button className="search-flight-card-price-button">
                                {flightdetails.Price}
                              </Button>
                            </td>
                          </tr>
                        </tbody> */}
                        </table>
                      </div>
                    </Drawer>
                  )}
                </div>
              );
            })
          ) : (
            <p>No flight data available</p>
          )}
        </div>
      </div>
      <button onClick={startPollingonClick}>Start Polling</button>
    </>
  );
};

export default Flightsearch;
